const country = require('./country.json');
const stateJson = require('./state.json');
module.exports = {
  country,
  stateJson,
};
