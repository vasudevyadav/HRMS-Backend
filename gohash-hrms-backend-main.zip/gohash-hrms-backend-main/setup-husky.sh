#!/bin/bash

# Install dependencies
npm install

# Set up Husky
npx husky install
